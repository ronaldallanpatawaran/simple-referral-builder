import React, { useEffect, useState } from "react";
import { Container, Box, useTheme, useMediaQuery } from "@mui/material";
import Form from "./components/Form";
import BasicTable from "./components/Table";
import axios from "axios";
import { ReferralData } from "./types/ReferralData";
import { ApiResponse } from "./types/Axios";


const App: React.FC = () => {
  const [rows, setRows] = useState<ReferralData[]>([] as ReferralData[]);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down(1024));

  const handleGetReferrals = async () => {
    try {
      const response = await axios.get<ApiResponse<ReferralData[]>>('http://localhost:5000/referrals');
      const referrals = response.data.data as ReferralData[];
      setRows(referrals);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    handleGetReferrals();
  }, [])

  return (
    <Container className="container">
      <Box sx={{ display: 'flex', flexDirection: !isMobile ? "row" : "column" }} gap={1}>
        <Form refresh={handleGetReferrals} />
        <Box sx={{ display: 'flex', paddingTop: '100px', paddingBottom: '100px', alignItems: 'top' }} gap={1} >
          <BasicTable rows={rows} />
        </Box>
      </Box>
    </Container>
  );
};

export default App;