import React, { useState } from "react";
import { TextField, Button, Box, Divider, Typography, useMediaQuery, useTheme } from "@mui/material";
import axios from "axios";
import { ReferralData } from "../types/ReferralData";

interface FormProps {
  refresh: () => void;
}

const Form: React.FC<FormProps> = ({ refresh }) => {
  const [formData, setFormData] = useState<ReferralData>({
    name: '',
    surname: '',
    email: '',
    phone: '',
    home: '',
    street: '',
    suburb: '',
    state: '',
    postcode: 0,
    country: '',
  });

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down(915));

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async () => {
    try {
      const response = await axios.post("http://localhost:5000/referrals", formData);
      refresh();
      alert("Referral Created Successfully: " + response.data.name);
    } catch (error) {
      console.error("Error creating referral:", error);
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ display: "flex", flexDirection: "column", gap: 2, padding: "15px" }}>
      <Typography variant="h4" className="form-title">Referral Builder</Typography>
      <Typography>PERSONAL DETAILS</Typography>
      <Divider />
      <Box sx={{ display: "flex", flexDirection: isMobile ? "column" : "row", gap: 5, padding: '10px' }}>
        <Box sx={{ display: "flex", flexDirection: "column", gap: 1, width: '100%' }}>
          <TextField required fullWidth label="Given name" name="name" slotProps={{ inputLabel: { shrink: true } }} onChange={handleChange} />
          <TextField required fullWidth label="Surname" name="surname" slotProps={{inputLabel: {shrink: true}}} onChange={handleChange} />
        </Box>
        <Box sx={{ display: "flex", flexDirection: "column", gap: 1, width: '100%' }}>
          <TextField required fullWidth label="Email" name="email" slotProps={{inputLabel: {shrink: true}}} onChange={handleChange} />
          <TextField required fullWidth label="Phone" name="email" slotProps={{inputLabel: {shrink: true}}} onChange={handleChange} />
        </Box>
      </Box>
      <Divider />
      <Box sx={{ display: "flex", flexDirection: isMobile ? "column" : "row", gap: 5, padding: '10px' }}>
        <Box sx={{ display: "flex", flexDirection: "column", gap: 1, width: '100%' }}>
          <TextField required className="fullWidth" label="Home Name OR#" slotProps={{inputLabel: {shrink: true}}} name="name" onChange={handleChange} />
          <TextField required fullWidth label="SubUrb" name="suburb" slotProps={{ inputLabel: { shrink: true } }} onChange={handleChange} />
          <TextField type="number" required fullWidth label="Postcode" name="postcode" slotProps={{inputLabel: {shrink: true}}} onChange={handleChange} />
        </Box>
        <Box sx={{ display: "flex", flexDirection: "column", gap: 1, width: '100%' }}>
          <TextField required fullWidth label="Street" name="street" slotProps={{inputLabel: {shrink: true}}} onChange={handleChange} />
          <TextField required fullWidth label="State" name="state" slotProps={{ inputLabel: { shrink: true } }} onChange={handleChange} />
          <TextField required fullWidth label="Country" name="country" slotProps={{inputLabel: {shrink: true}}} onChange={handleChange} />
        </Box>
      </Box>
      <Box sx={{ display: "flex", flexDirection: "row", gap: 2 }}>
        <Button className="secondary" variant="contained" style={{ width: '50%', height: '50px' }} color="secondary">
          Upload Avatar
        </Button>
        <Button type="submit" className="primary" variant="contained" style={{ width: '50%', height: '50px' }} color="primary">
          Create Referral
        </Button>
      </Box>
    </Box>
  );
};

export default Form;